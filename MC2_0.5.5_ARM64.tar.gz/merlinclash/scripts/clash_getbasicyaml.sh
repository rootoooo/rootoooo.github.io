#!/bin/sh

export KSROOT=/koolshare
source $KSROOT/scripts/base.sh
eval $(dbus export merlinclash_)
alias echo_date='echo 【$(date +%Y年%m月%d日\ %X)】:'
#
#host
rm -rf  /tmp/upload/clash_hosts.txt
ln -sf /koolshare/merlinclash/yaml_basic/hosts.yaml /tmp/upload/clash_hosts.txt
#dns
[ ! -L "/tmp/upload/clash_redirhost.txt" ] && ln -s /koolshare/merlinclash/yaml_dns/redirhost.yaml /tmp/upload/clash_redirhost.txt
[ ! -L "/tmp/upload/clash_fakeip.txt" ] && ln -s /koolshare/merlinclash/yaml_dns/fakeip.yaml /tmp/upload/clash_fakeip.txt
#sniffer
rm -rf /tmp/upload/clash_sniffercontent.txt
ln -sf /koolshare/merlinclash/yaml_basic/sniffer.yaml /tmp/upload/clash_sniffercontent.txt
#iptlist
rm -rf /tmp/upload/clash_ipsetproxyarround.txt
rm -rf /tmp/upload/clash_ipsetproxy.txt
if [ -f "/koolshare/merlinclash/yaml_basic/ipsetproxyarround.yaml" ]; then
	ln -sf /koolshare/merlinclash/yaml_basic/ipsetproxyarround.yaml /tmp/upload/clash_ipsetproxyarround.txt
fi
if [ -f "/koolshare/merlinclash/yaml_basic/ipsetproxy.yaml" ]; then
	ln -sf /koolshare/merlinclash/yaml_basic/ipsetproxy.yaml /tmp/upload/clash_ipsetproxy.txt
fi
http_response $1