#!/bin/sh

export KSROOT=/koolshare
source $KSROOT/scripts/base.sh
eval $(dbus export merlinclash_)
alias echo_date='echo 【$(date +%Y年%m月%d日\ %X)】:'
LOG_FILE=/tmp/upload/merlinclash_log.txt
LOCK_FILE=/tmp/ipdb_update.lock
rm -rf $LOG_FILE

uploadpath=/tmp/upload
tmpStoragePath=
fileIsValid="0"

curl=$(which curl)
wget=$(which wget)

geoip_lite_url="https://github.com/MetaCubeX/meta-rules-dat/releases/download/latest/geoip-lite.dat"
geoip_lite_cdn="https://testingcf.jsdelivr.net/gh/MetaCubeX/meta-rules-dat@release/geoip-lite.dat"
geoip_full_url="https://github.com/MetaCubeX/meta-rules-dat/releases/download/latest/geoip.dat"
geoip_full_cdn="https://testingcf.jsdelivr.net/gh/MetaCubeX/meta-rules-dat@release/geoip.dat"

geosite_default_url="https://github.com/flyhigherpi/merlinclash_clash_related/raw/refs/heads/master/geosite/geosite.dat"
geosite_default_cdn="https://testingcf.jsdelivr.net/gh/flyhigherpi/merlinclash_clash_related@refs/heads/master/geosite/geosite.dat"
geosite_lite_url="https://github.com/MetaCubeX/meta-rules-dat/releases/download/latest/geosite-lite.dat"
geosite_lite_cdn="https://testingcf.jsdelivr.net/gh/MetaCubeX/meta-rules-dat@release/geosite-lite.dat"
geosite_full_url="https://github.com/MetaCubeX/meta-rules-dat/releases/download/latest/geosite.dat"
geosite_full_cdn="https://testingcf.jsdelivr.net/gh/MetaCubeX/meta-rules-dat@release/geosite.dat"


check_size(){
    SPACE_FILE=$(du -s "$1" | awk '{print $1}')
    if [ ! -f "$1" ] || [ "$SPACE_FILE" -eq "0" ]; then
        echo "0"
    else
        echo "1"
    fi
}

downloadFile(){
    local url=$1
    local filePath=$2
    if [ ! "$url" ] || [  ! "$filePath" ];then
        echo_date "下载地址或存储文件名不存在，停止下载！！" >> $LOG_FILE
        echo BBABBBBC >> $LOG_FILE
        exit 1
    fi
    
    if [ "x$curl" != "x" ] && [ -x $curl ]; then
    	echo_date "------------------使用Curl下载---------------------" >> $LOG_FILE
        $curl -k -w "%{time_total}s" $url -o $filePath >> $LOG_FILE 2>&1
        echo " " >> $LOG_FILE
        echo_date "--------------------------------------------------" >> $LOG_FILE
    elif [ "x$wget" != "x" ] && [ -x $wget ]; then
    	echo_date "------------------使用wget下载------------------" >> $LOG_FILE
        $wget --no-check-certificate --tries=3 $url -O $filePath >> $LOG_FILE 2>&1
        echo_date "--------------------------------------------------" >> $LOG_FILE
    else
        echo_date "没有找到 wget 或 curl，无法更新 IP 数据库！" >> $LOG_FILE
        echo BBABBBBC >> $LOG_FILE
        exit 1
    fi
    fileIsValid=$(check_size $2)
}

update_ipdb(){
    #下载Geoip
    echo_date "========================================================="
    version=${merlinclash_updata_date}
    if [ "${merlinclash_geoip_type}" == "lite" ]; then
        echo_date "开始更新GeoIP-Lite数据库"
        geoip_url=$geoip_lite_url
        geoip_cdn=$geoip_lite_cdn
    elif [ "${merlinclash_geoip_type}" == "full" ]; then
        echo_date "开始更新GeoIP-Full数据库"
        geoip_url=$geoip_full_url
        geoip_cdn=$geoip_full_cdn
    else
        echo_date "未读取数据库版本设置，默认更新GeoIP-lite数据库"
        geoip_url=$geoip_lite_url
        geoip_cdn=$geoip_lite_cdn
    fi
    tmpStoragePath="$uploadpath/GeoIP.dat"
    echo_date "开始从CDN地址下载 GeoIP 数据库..." 
    downloadFile $geoip_cdn $tmpStoragePath
        
        if [ "$fileIsValid" == "1" ]; then  
            echo_date "GeoIP数据库下载成功！"
        else
            echo_date "从CDN地址下载失败，尝试从原始地址下载"
            downloadFile $geoip_url $tmpStoragePath
        fi
        
        if [ "$fileIsValid" == "1" ]; then
            echo_date "下载完成，开始替换" >> $LOG_FILE
            echo_date 检测jffs分区剩余空间... >> $LOG_FILE
            SPACE_AVAL=$(df|grep jffs|head -n 1  | awk '{print $4}')
            SPACE_NEED=$(du -s $tmpStoragePath | awk '{print $1}')
            if [ "$SPACE_AVAL" -gt "$SPACE_NEED" ];then
                echo_date 当前jffs分区剩余"$SPACE_AVAL" KB, 数据库需要"$SPACE_NEED" KB，空间满足，继续安装！>> $LOG_FILE
                echo_date "更新数据库" >> $LOG_FILE
                cp -rf $tmpStoragePath /koolshare/merlinclash/GeoIP.dat
                dbus set merlinclash_ipdb_version=$version         
                echo_date "清理临时文件..." >> $LOG_FILE
                rm -rf $tmpStoragePath
                
                echo_date "GeoIP 数据库更新完成！" >> $LOG_FILE
                sleep 1
            else
                echo_date 当前jffs分区剩余"$SPACE_AVAL" KB, 数据库需要"$SPACE_NEED" KB，空间不足！>> $LOG_FILE
                echo_date GeoIP数据库下载失败，继续更新GeoSite数据库>> $LOG_FILE
            fi
        else
            echo_date "GeoIP数据库下载失败，继续更新GeoSite数据库"     
        fi

    #下载GeoSite
    echo_date "========================================================="
    if [ "${merlinclash_geosite_type}" == "lite" ]; then
        echo_date "开始更新GeoSite-Lite数据库"
        geosite_url=$geosite_lite_url
        geosite_cdn=$geosite_lite_cdn
    elif [ "${merlinclash_geosite_type}" == "full" ]; then
        echo_date "开始更新GeoSite-Full数据库"
        geosite_url=$geosite_full_url
        geosite_cdn=$geosite_full_cdn
    else
        echo_date "开始更新GeoSite-Default数据库"
        geosite_url=$geosite_default_url
        geosite_cdn=$geosite_default_cdn
    fi

    tmpStoragePath="$uploadpath/geosite.dat"
    echo_date "开始从CDN地址下载 GeoSite 数据库..." 
    downloadFile $geosite_cdn $tmpStoragePath

        if [ "$fileIsValid" == "1" ]; then  
            echo_date "数据库下载成功！"
        else
            echo_date "数据库下载失败，尝试从原始地址下载"
            sleep 1
            downloadFile $geosite_url $tmpStoragePath
        fi
        
        if [ "$fileIsValid" == "1" ]; then
            echo_date "下载完成，开始替换" >> $LOG_FILE
            echo_date 检测jffs分区剩余空间... >> $LOG_FILE
            SPACE_AVAL=$(df|grep jffs|head -n 1  | awk '{print $4}')
            SPACE_NEED=$(du -s $tmpStoragePath | awk '{print $1}')
            if [ "$SPACE_AVAL" -gt "$SPACE_NEED" ];then
                echo_date 当前jffs分区剩余"$SPACE_AVAL" KB, 数据库需要"$SPACE_NEED" KB，空间满足，继续安装！>> $LOG_FILE
                echo_date "更新数据库" >> $LOG_FILE
                cp -rf $tmpStoragePath /koolshare/merlinclash/GeoSite.dat
                dbus set merlinclash_ipdb_version=$version
                echo_date "清理临时文件..." >> $LOG_FILE
                rm -rf $tmpStoragePath
                echo_date "GeoSite数据库更新完成！" >> $LOG_FILE
                echo_date "注意！新版数据库将在下次启动 Clash 时生效！" >> $LOG_FILE
                sleep 1
            else
                echo_date 当前jffs分区剩余"$SPACE_AVAL" KB, 数据库需要"$SPACE_NEED" KB，空间不足！>> $LOG_FILE
                echo_date GeoSite数据库下载失败，退出更新>> $LOG_FILE
                echo BBABBBBC >> $LOG_FILE
                exit 1
            fi
        else
            echo_date "GeoSite数据库下载失败，退出更新"
            echo BBABBBBC >> $LOG_FILE
            exit 1 
        fi
        echo_date "========================================================="
}

set_lock(){
	exec 233>"$LOCK_FILE"
	flock -n 233 || {
		echo_date "数据库升级已经在运行，请稍候再试！" >> $LOG_FILE	
		unset_lock
	}
}

unset_lock(){
	flock -u 233
	rm -rf "$LOCK_FILE"
}

case $2 in
5)
	set_lock

	echo "" > $LOG_FILE
	http_response "$1"
	echo_date "数据库更新" >> $LOG_FILE
	update_ipdb>> $LOG_FILE
	echo BBABBBBC >> $LOG_FILE
	unset_lock
	;;
esac